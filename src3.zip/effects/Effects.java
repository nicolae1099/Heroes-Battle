package effects;

import heroes.Hero;

public interface Effects {
    void apply(Hero defender);
}
